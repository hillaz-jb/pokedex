import { Component, OnInit } from '@angular/core';
import {SpokedexService} from "../services/spokedex.service";
import {IPokemon} from "../../models/pokemon";
import {IPokemonList} from "../../models/pokemonList";

@Component({
  selector: 'app-globalpokedex',
  templateUrl: './globalpokedex.component.html',
  styleUrls: ['./globalpokedex.component.scss']
})
export class GlobalpokedexComponent implements OnInit {
  myPoke: IPokemon = this.mySpokedex.IMyPoke;
  constructor(private mySpokedex: SpokedexService) { }

  ngOnInit(): void {
    console.log(this.mySpokedex.getPokemon());
    this.mySpokedex.getPokemon().subscribe((data : IPokemon) => {
      this.myPoke = this.mySpokedex.IMyPoke;
    });
  }
}
