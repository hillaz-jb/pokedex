import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {IPokemon} from "../../models/pokemon";
import {IPokemonList} from "../../models/pokemonList";

@Injectable({
  providedIn: 'root'
})
export class SpokedexService {
  arrayMyPoke : Array<IPokemon> = [];
  IMyPoke! : IPokemon;
  limit: number = 20;
  constructor(private myHttpClient: HttpClient) { }


  getPokemon(): Observable<IPokemon> {
    const myObservable = this.myHttpClient.get<IPokemon>("https://pokeapi.co/api/v2/pokemon/25");
    myObservable.subscribe((data : IPokemon) => {
      //console.log(data);
      this.IMyPoke = data;
    });
    return myObservable;
  }



  getSomePokemon(): Observable<Array<IPokemon>> {
    for (let i = 0; i < this.limit; i++ ){
      const myObservable2 = this.myHttpClient.get<IPokemon>("https://pokeapi.co/api/v2/pokemon/"+this.limit);
      myObservable.subscribe((data : IPokemon) => {
        //console.log(data);
        this.IMyPoke = data;
      });
    }

    return myObservable2;
  }
}
